-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Εξυπηρετητής: 127.0.0.1
-- Χρόνος δημιουργίας: 15 Φεβ 2022 στις 18:05:05
-- Έκδοση διακομιστή: 10.4.22-MariaDB
-- Έκδοση PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `covid_cases_db`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `new_covid_blockchain`
--

CREATE TABLE `new_covid_blockchain` (
  `id` int(11) NOT NULL,
  `hash` varchar(120) COLLATE utf8_general_mysql500_ci NOT NULL,
  `previous_hash` varchar(120) COLLATE utf8_general_mysql500_ci NOT NULL,
  `nonce` int(15) NOT NULL,
  `query_date` bigint(20) DEFAULT NULL,
  `countryData` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `type` varchar(30) COLLATE utf8_general_mysql500_ci NOT NULL,
  `country` varchar(50) COLLATE utf8_general_mysql500_ci NOT NULL,
  `year` int(4) DEFAULT NULL,
  `month` int(2) DEFAULT NULL,
  `deaths` int(7) NOT NULL,
  `confirmed` int(7) NOT NULL,
  `monthCumulativeNumber` double(10,3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_mysql500_ci;

--
-- Άδειασμα δεδομένων του πίνακα `new_covid_blockchain`
--

INSERT INTO `new_covid_blockchain` (`id`, `hash`, `previous_hash`, `nonce`, `query_date`, `countryData`, `type`, `country`, `year`, `month`, `deaths`, `confirmed`, `monthCumulativeNumber`) VALUES
(16, '000009c5f55e27e318d1532742d3014dd45e240eff9675207e3207c40643881c', '0', 29398, 1644883200, '{\"data\":{\"location\":\"Greece\",\"confirmed\":2194453,\"deaths\":24836,\"recovered\":0,\"active\":0,\"averageCumulativeNumberOfCasesFor2Weeks\":0.0},\"dt\":\"02-15-2022\",\"ts\":1644883200,\"typeOfData\":\"aggregated\"}', 'aggregated', 'Greece', -1, -1, 24836, 2194453, 0.000),
(17, '000000f6508280098a486db8295c9828fac11a36edb7aa42bde7bc8c97ac0438', '000009c5f55e27e318d1532742d3014dd45e240eff9675207e3207c40643881c', 1130176, 1644937986607, '{\"data\":{\"location\":\"Finland\",\"confirmed\":6181,\"deaths\":60,\"recovered\":0,\"active\":0,\"averageCumulativeNumberOfCasesFor2Weeks\":109.31786835928571,\"month\":\"12\",\"year\":\"2020\"},\"dt\":\"02-15-2022\",\"ts\":1644937986607,\"typeOfData\":\"monthly\"}', 'monthly', 'Finland', 2020, 12, 60, 6181, 109.318),
(18, '00000df5a19003b5f7d731fb924b256c1d96e2317409fc66bb220ae168b3cdcc', '0', 2549669, 1644883200, '{\"data\":{\"location\":\"Spain\",\"confirmed\":10672906,\"deaths\":96596,\"recovered\":0,\"active\":0,\"averageCumulativeNumberOfCasesFor2Weeks\":0.0},\"dt\":\"02-15-2022\",\"ts\":1644883200,\"typeOfData\":\"aggregated\"}', 'aggregated', 'Spain', -1, -1, 96596, 10672906, 0.000),
(19, '00000f8c3d6ec547b22b09b7badabb8ebdbb66a5baf551efe9a14721f9545ec5', '00000df5a19003b5f7d731fb924b256c1d96e2317409fc66bb220ae168b3cdcc', 2643927, 1644939431377, '{\"data\":{\"location\":\"Spain\",\"confirmed\":82388,\"deaths\":2555,\"recovered\":0,\"active\":0,\"averageCumulativeNumberOfCasesFor2Weeks\":253.85336808846156,\"month\":\"12\",\"year\":\"2020\"},\"dt\":\"02-15-2022\",\"ts\":1644939431377,\"typeOfData\":\"monthly\"}', 'monthly', 'Spain', 2020, 12, 2555, 82388, 253.853),
(20, '00000d93ae02368d1dfa9679130c6e8004adc8615d7e1341d97a1d0f0ff681ce', '0', 1371017, 1644883200, 'Country@2ce59e9b', 'aggregated', 'Germany', -1, -1, 120227, 12628843, 0.000),
(21, '000003d3133b254a35760a0716f87ddfe592bceeaed1dd75f94c3116fcc0cf30', '0', 2018499, 1644883200, '{\"data\":{\"location\":\"Greece\",\"confirmed\":2194453,\"deaths\":24836,\"recovered\":0,\"active\":0,\"averageCumulativeNumberOfCasesFor2Weeks\":0.0},\"dt\":\"02-15-2022\",\"ts\":1644883200,\"typeOfData\":\"aggregated\"}', 'aggregated', 'Greece', -1, -1, 24836, 2194453, 0.000),
(22, '000003d1d676228fe3a8fed4b7683165dde714b698ddaee8a4082a6cb5d1cab5', '000003d3133b254a35760a0716f87ddfe592bceeaed1dd75f94c3116fcc0cf30', 2159807, 1644940578769, '{\"data\":{\"location\":\"France\",\"confirmed\":51,\"deaths\":2,\"recovered\":0,\"active\":0,\"averageCumulativeNumberOfCasesFor2Weeks\":0.01121760448275862,\"month\":\"2\",\"year\":\"2020\"},\"dt\":\"02-15-2022\",\"ts\":1644940578769,\"typeOfData\":\"monthly\"}', 'monthly', 'France', 2020, 2, 2, 51, 0.011),
(23, '000003d3133b254a35760a0716f87ddfe592bceeaed1dd75f94c3116fcc0cf30', '0', 2018499, 1644883200, '{\"data\":{\"location\":\"Greece\",\"confirmed\":2194453,\"deaths\":24836,\"recovered\":0,\"active\":0,\"averageCumulativeNumberOfCasesFor2Weeks\":0.0},\"dt\":\"02-15-2022\",\"ts\":1644883200,\"typeOfData\":\"aggregated\"}', 'aggregated', 'Greece', -1, -1, 24836, 2194453, 0.000);

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `new_covid_blockchain`
--
ALTER TABLE `new_covid_blockchain`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `new_covid_blockchain`
--
ALTER TABLE `new_covid_blockchain`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
